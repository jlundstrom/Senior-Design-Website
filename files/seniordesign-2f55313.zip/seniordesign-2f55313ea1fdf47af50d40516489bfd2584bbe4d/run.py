import collections, fnmatch, os, re

words = []
for root, dirnames, filenames in os.walk('docs'):
	for filename in fnmatch.filter(filenames, '*.tex'):
		words += re.findall('\W(\w{4,})\W', open(os.path.join(root, filename), 'r').read())

words = [a.lower() for a in words]

cc =  collections.Counter(words)

print len(cc)
print cc.most_common(50)
