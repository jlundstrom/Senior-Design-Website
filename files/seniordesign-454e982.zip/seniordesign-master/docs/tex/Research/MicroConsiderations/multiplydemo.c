int multiply(void)
{
	volatile unsigned int i=0;
	volatile unsigned int multiplicand=2;
	volatile unsigned int multiplier=4;
	volatile unsigned int accumulator=0;
	for (i=0;i<multiplier;i++) {
		accumulator += multiplicand;
	}
	return accumulator;
}