make sure to fix the config file, is set to my computer settings -Celes

mode 1 -BW
mode 2 -Color