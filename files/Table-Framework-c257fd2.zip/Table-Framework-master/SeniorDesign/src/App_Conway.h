#ifndef __APP_CONWAY__
#define __APP_CONWAY__
#include "App.h"

extern void App_Conway_New(App* app);
#endif
