#ifndef __APP_GO__
#define __APP_GO__
#include "App.h"

extern void App_Go_New(App* app);
#endif
