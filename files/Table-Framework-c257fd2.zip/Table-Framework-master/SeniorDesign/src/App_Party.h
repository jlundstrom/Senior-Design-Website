#ifndef __APP_PARTY__
#define __APP_PARTY__
#include "App.h"

extern void App_Party_New(App* app);
#endif
