#ifndef __APP_MENU__
#define __APP_MENU__
#include "App.h"

extern void App_Menu_New(App* app);
extern void App_Menu_Poll(void);
#endif
