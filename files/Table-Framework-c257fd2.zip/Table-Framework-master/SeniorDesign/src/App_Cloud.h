#ifndef __APP_CLOUD__
#define __APP_CLOUD__
#include "App.h"

extern void App_Cloud_New(App* app);
#endif
