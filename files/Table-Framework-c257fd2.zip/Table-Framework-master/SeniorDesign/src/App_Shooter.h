#ifndef __APP_SHOOT__
#define __APP_SHOOT__
#include "App.h"

extern void App_Shoot_New(App* app);
#endif
