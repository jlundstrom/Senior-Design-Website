#ifndef __APP_TETRIS__
#define __APP_TETRIS__
#include "App.h"

extern void App_Tetris_New(App* app);
#endif
