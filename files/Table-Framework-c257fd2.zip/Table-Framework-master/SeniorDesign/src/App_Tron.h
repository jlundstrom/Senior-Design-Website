#ifndef __APP_TRON__
#define __APP_TRON__
#include "App.h"

extern void App_Tron_New(App* app);
#endif
