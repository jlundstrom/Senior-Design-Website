#ifndef __APP_CLOCK__
#define __APP_CLOCK__
#include "App.h"

extern void App_Clock_New(App* app);
#endif
