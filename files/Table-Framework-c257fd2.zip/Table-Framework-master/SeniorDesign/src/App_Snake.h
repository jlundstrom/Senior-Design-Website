#ifndef __APP_SNAKE__
#define __APP_SNAKE__
#include "App.h"

extern void App_Snake_New(App* app);
#endif
