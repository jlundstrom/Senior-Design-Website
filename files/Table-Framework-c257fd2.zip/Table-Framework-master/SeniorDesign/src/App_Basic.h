#ifndef __APP_BASIC__
#define __APP_BASIC__
#include "App.h"

extern void App_Basic_New(App* app);
#endif
