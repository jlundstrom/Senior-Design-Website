#ifndef __APP_BOOT__
#define __APP_BOOT__
#include "App.h"

extern void App_Boot_New(App* app);
#endif
