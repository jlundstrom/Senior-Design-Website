# Table-Framework

## F28379D
Import SeniorDesign into Code Composer Studios 7+, and do not move the folder.
The local repo folder can also be used as the Code Composer Workspace.

## Emulator
Open Solution in Emulator

## Troubleshooting
If you get the error "unresolved external symbol Display_init" referenced in function main. Add "WIN32" to Project Properties->C/C++->Preprocessor->Preprocessor Definitions